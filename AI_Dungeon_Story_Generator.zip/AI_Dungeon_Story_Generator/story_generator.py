from transformers import GPT2LMHeadModel, GPT2Tokenizer
import streamlit as st
import torch

# Load Pretrained GPT-2 model and tokenizer
model_name = "gpt2"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
# Move model to the appropriate device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

def generate_story(prompt):
    inputs = tokenizer.encode(prompt, return_tensors='pt').to(device)
    outputs = model.generate(inputs, max_length=500, num_return_sequences=3, do_sample=True, top_k=50, top_p=0.95, no_repeat_ngram_size=2)
    stories = []
    for output in outputs:
        stories.append(tokenizer.decode(output, skip_special_tokens=True))
    return stories

# Streamlit UI
st.title("AI Dungeon Story Generator")
user_input = st.text_area("Enter the beginning of your story:")
genre = st.selectbox("Choose Genre", ["Fantasy", "Mystery", "Sci-Fi", "Horror"])

if st.button("Generate Story"):
    if user_input:
        generated_stories = generate_story(user_input)
        for idx, story in enumerate(generated_stories, 1):
            st.write(f"Story {idx}:\n{story}\n")
        # Save the story as text file
        with open("generated_story.txt", "w") as file:
            file.write(generated_stories[0])  # Saving the first story
        st.write("Story saved as generated_story.txt")
    else:
        st.write("Please enter a prompt to generate the story.")